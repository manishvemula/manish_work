#!/bin/bash
PCHP=/sys/class/pwm/pwmchip0
CH=0
PERIOD=2000000   # 2ms -> 500Hz (change to 20000000 for 50Hz)

# make sure pwm0 exists; if not, export it
if [ ! -d "$PCHP/pwm$CH" ]; then
  echo $CH | sudo tee $PCHP/export
  sleep 0.1
fi

# set period
echo $PERIOD | sudo tee $PCHP/pwm$CH/period

# fade
while true; do
  for i in $(seq 0 5 100); do
    duty=$((PERIOD * i / 100))
    echo $duty | sudo tee $PCHP/pwm$CH/duty_cycle
    echo 1 | sudo tee $PCHP/pwm$CH/enable
    sleep 0.1
  done
  for i in $(seq 100 -5 0); do
    duty=$((PERIOD * i / 100))
    echo $duty | sudo tee $PCHP/pwm$CH/duty_cycle
    echo 1 | sudo tee $PCHP/pwm$CH/enable
    sleep 0.1
  done
done
