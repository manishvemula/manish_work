// led_pwm_fade_driver_fallback.c
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/pwm.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/err.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/string.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("manish");
MODULE_DESCRIPTION("PWM LED Fade driver with PWM API fallback to sysfs");

// Module params
static unsigned int period_ns = 2000000; // default 2ms => 500Hz
module_param(period_ns, uint, 0444);
MODULE_PARM_DESC(period_ns, "PWM period in ns");

static unsigned int step_percent = 5; // step size in percent
module_param(step_percent, uint, 0444);
MODULE_PARM_DESC(step_percent, "Duty step percentage");

static unsigned int delay_ms = 100; // delay between steps in ms
module_param(delay_ms, uint, 0444);
MODULE_PARM_DESC(delay_ms, "Delay between duty steps (ms)");

/* runtime state */
static struct pwm_device *pwm = NULL;
static struct task_struct *fade_thread = NULL;
static bool use_sysfs = false;

/* sysfs paths */
#define PWMCHIP     "/sys/class/pwm/pwmchip0"
#define PWM0_DIR    PWMCHIP "/pwm0"
#define EXPORT_PATH PWMCHIP "/export"
#define UNEXPORT_PATH PWMCHIP "/unexport"
#define DUTY_PATH   PWM0_DIR "/duty_cycle"
#define PERIOD_PATH PWM0_DIR "/period"
#define ENABLE_PATH PWM0_DIR "/enable"

/* write string to sysfs file using kernel_write */
static int write_sysfs_str(const char *path, const char *s)
{
    struct file *f;
    loff_t pos = 0;
    ssize_t ret;

    f = filp_open(path, O_WRONLY | O_CLOEXEC, 0);
    if (IS_ERR(f)) {
        pr_debug("led_pwm: open %s failed: %ld\n", path, PTR_ERR(f));
        return PTR_ERR(f);
    }

    ret = kernel_write(f, s, strlen(s), &pos);
    filp_close(f, NULL);

    if (ret < 0)
        pr_debug("led_pwm: write %s failed: %zd\n", path, ret);

    return (int)ret;
}

static int write_sysfs_int(const char *path, long value)
{
    char buf[32];
    snprintf(buf, sizeof(buf), "%ld", value);
    return write_sysfs_str(path, buf);
}

/* ensure pwm0 exists (export if needed) */
static void ensure_exported(void)
{
    struct file *d;

    d = filp_open(PWM0_DIR, O_RDONLY, 0);
    if (!IS_ERR(d)) {
        filp_close(d, NULL);
        return;
    }

    /* export channel 0 */
    write_sysfs_int(EXPORT_PATH, 0);
    msleep(50);
}

/* fade thread */
static int fade_fn(void *data)
{
    long step_ns = (period_ns * step_percent) / 100;
    long d;

    pr_info("led_pwm: fade thread started (period %u ns, step %u %%)\n",
            period_ns, step_percent);

    while (!kthread_should_stop()) {
        if (use_sysfs) {
            /* sysfs method */
            for (d = 0; d <= (long)period_ns && !kthread_should_stop(); d += step_ns) {
                write_sysfs_int(DUTY_PATH, d);
                write_sysfs_int(ENABLE_PATH, 1);
                msleep(delay_ms);
            }
            for (d = period_ns; d >= 0 && !kthread_should_stop(); d -= step_ns) {
                write_sysfs_int(DUTY_PATH, d);
                write_sysfs_int(ENABLE_PATH, 1);
                msleep(delay_ms);
            }
        } else {
            /* PWM API method */
            long i;
            for (i = 0; i <= (long)period_ns && !kthread_should_stop(); i += step_ns) {
                pwm_config(pwm, i, period_ns);
                pwm_enable(pwm);
                msleep(delay_ms);
            }
            for (i = period_ns; i >= 0 && !kthread_should_stop(); i -= step_ns) {
                pwm_config(pwm, i, period_ns);
                pwm_enable(pwm);
                msleep(delay_ms);
            }
        }
    }

    pr_info("led_pwm: fade thread stopping\n");
    return 0;
}

static int __init led_pwm_init(void)
{
    int ret = 0;

    pr_info("led_pwm: init (period=%u ns)\n", period_ns);

    /* Try kernel PWM API first */
    pwm = pwm_get(NULL, "pwm0");
    if (IS_ERR(pwm)) {
        pr_warn("led_pwm: pwm_get(NULL,\"pwm0\") failed (%ld), trying pwmchip0:0\n",
                PTR_ERR(pwm));
        pwm = pwm_get(NULL, "pwmchip0:0");
    }

    if (IS_ERR(pwm)) {
        pr_warn("led_pwm: kernel PWM API unavailable, falling back to sysfs\n");
        pwm = NULL;
        use_sysfs = true;

        ensure_exported();

        /* disable then set period/duty and enable */
        write_sysfs_int(ENABLE_PATH, 0);
        write_sysfs_int(PERIOD_PATH, period_ns);
        write_sysfs_int(DUTY_PATH, 0);
        write_sysfs_int(ENABLE_PATH, 1);
    } else {
        /* configure via API */
        ret = pwm_config(pwm, 0, period_ns);
        if (ret < 0) {
            pr_warn("led_pwm: pwm_config failed: %d, falling back to sysfs\n", ret);
            pwm_put(pwm);
            pwm = NULL;
            use_sysfs = true;
            ensure_exported();
            write_sysfs_int(ENABLE_PATH, 0);
            write_sysfs_int(PERIOD_PATH, period_ns);
            write_sysfs_int(DUTY_PATH, 0);
            write_sysfs_int(ENABLE_PATH, 1);
        } else {
            pwm_enable(pwm);
        }
    }

    fade_thread = kthread_run(fade_fn, NULL, "led_pwm_fade");
    if (IS_ERR(fade_thread)) {
        pr_err("led_pwm: kthread_run failed: %ld\n", PTR_ERR(fade_thread));
        fade_thread = NULL;
        if (pwm) {
            pwm_disable(pwm);
            pwm_put(pwm);
        }
        return -ENOMEM;
    }

    pr_info("led_pwm: module loaded (use_sysfs=%d)\n", use_sysfs);
    return 0;
}

static void __exit led_pwm_exit(void)
{
    pr_info("led_pwm: exit\n");

    if (fade_thread) {
        kthread_stop(fade_thread);
        fade_thread = NULL;
    }

    if (use_sysfs) {
        write_sysfs_int(ENABLE_PATH, 0);
        write_sysfs_int(UNEXPORT_PATH, 0);
    } else {
        if (pwm) {
            pwm_disable(pwm);
            pwm_put(pwm);
            pwm = NULL;
        }
    }

    pr_info("led_pwm: unloaded\n");
}

module_init(led_pwm_init);
module_exit(led_pwm_exit);
