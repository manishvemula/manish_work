#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0xa2296fa6, "pwm_apply_might_sleep" },
	{ 0xf0fdf6cb, "__stack_chk_fail" },
	{ 0x656e4a6e, "snprintf" },
	{ 0x1e477abd, "filp_open" },
	{ 0x98cf60b3, "strlen" },
	{ 0x9a4a2a5c, "kernel_write" },
	{ 0x9b13921b, "filp_close" },
	{ 0x92997ed8, "_printk" },
	{ 0xd45b3bc6, "kthread_stop" },
	{ 0x8ae0bcd8, "pwm_put" },
	{ 0xf9a482f9, "msleep" },
	{ 0xf9c592d8, "pwm_get" },
	{ 0xcb661d89, "kthread_create_on_node" },
	{ 0x20bc8744, "wake_up_process" },
	{ 0xb3f7646e, "kthread_should_stop" },
	{ 0x2f5de9ec, "param_ops_uint" },
	{ 0x474e54d2, "module_layout" },
};

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "E3D5A6C6FBB8D47B7145657");
